def calculate(expression):
    try:
        return eval(expression)
    except ZeroDivisionError:
        return "ПОМИЛКА: Ділення на нуль"
    except NameError:
        return "ПОМИЛКА: Треба вводити тільки числа"
    except SyntaxError:
        return "ПОМИЛКА: Незрозумілий символ"

while True:
    print(calculate(input("Введіть вираз: ")))